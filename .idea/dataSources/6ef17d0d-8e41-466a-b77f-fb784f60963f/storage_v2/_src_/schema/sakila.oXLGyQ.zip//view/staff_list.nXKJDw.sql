create definer = root@localhost view staff_list as
select `s`.`staff_id`                                 AS `ID`,
       concat(`s`.`first_name`, ' ', `s`.`last_name`) AS `name`,
       `a`.`address`                                  AS `address`,
       `a`.`postal_code`                              AS `zip code`,
       `a`.`phone`                                    AS `phone`,
       `sakila`.`city`.`city`                         AS `city`,
       `sakila`.`country`.`country`                   AS `country`,
       `s`.`store_id`                                 AS `SID`
from (((`sakila`.`staff` `s` join `sakila`.`address` `a`
        on ((`s`.`address_id` = `a`.`address_id`))) join `sakila`.`city`
       on ((`a`.`city_id` = `sakila`.`city`.`city_id`))) join `sakila`.`country`
      on ((`sakila`.`city`.`country_id` = `sakila`.`country`.`country_id`)));

